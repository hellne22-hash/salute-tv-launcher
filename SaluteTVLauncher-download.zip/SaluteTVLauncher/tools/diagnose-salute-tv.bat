@echo off
setlocal
if "%~1"=="" (
  echo Usage: diagnose-salute-tv.bat TV_IP_ADDRESS [ADB_PORT]
  echo Example: diagnose-salute-tv.bat 192.168.1.50 5555
  exit /b 1
)
set PORT=%~2
if "%PORT%"=="" set PORT=5555
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0diagnose-salute-tv.ps1" -TvHost "%~1" -Port %PORT%
endlocal
