# Read-only Salute TV diagnostic via ADB. Does not modify TV settings or packages.
# Usage: .\diagnose-salute-tv.ps1 -TvHost 192.168.1.50
param(
  [Parameter(Mandatory=$true)][string]$TvHost,
  [int]$Port = 5555,
  [string]$OutputDir = ".\salute-tv-report"
)
$ErrorActionPreference = 'Stop'
$adb = Get-Command adb -ErrorAction SilentlyContinue
if (-not $adb) { Write-Error "ADB not found. Install Android SDK Platform-Tools and ensure adb.exe is in PATH." }
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
$log = Join-Path $OutputDir ("salute-tv-diagnostic-{0}.txt" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
function Run-Adb([string[]]$Args) {
  $out = & $script:adb.Source @Args 2>&1
  return ($out | Out-String).TrimEnd()
}
"Salute TV read-only diagnostic" | Set-Content -Encoding UTF8 $log
"Date: $(Get-Date -Format o)" | Add-Content -Encoding UTF8 $log
"Target: ${TvHost}:$Port" | Add-Content -Encoding UTF8 $log
$devices = Run-Adb @('devices')
"`n=== adb devices ===`n$devices" | Add-Content -Encoding UTF8 $log
$connect = Run-Adb @('connect', "${TvHost}:$Port")
"`n=== adb connect ===`n$connect" | Add-Content -Encoding UTF8 $log
$state = Run-Adb @('-s', "${TvHost}:$Port", 'get-state')
"`n=== device state ===`n$state" | Add-Content -Encoding UTF8 $log
if ($state -notmatch 'device') {
  Write-Host "Connection failed. On the TV enable ADB/network debugging and approve this computer, then rerun."
  Write-Host "Details: $log"
  exit 2
}
$commands = [ordered]@{
  'Build fingerprint' = @('shell','getprop','ro.build.fingerprint')
  'Manufacturer' = @('shell','getprop','ro.product.manufacturer')
  'Brand' = @('shell','getprop','ro.product.brand')
  'Model' = @('shell','getprop','ro.product.model')
  'Device' = @('shell','getprop','ro.product.device')
  'Android release' = @('shell','getprop','ro.build.version.release')
  'SDK level' = @('shell','getprop','ro.build.version.sdk')
  'Build ID' = @('shell','getprop','ro.build.id')
  'Firmware version' = @('shell','getprop','ro.build.display.id')
  'Resolution / density' = @('shell','wm','size')
  'Density' = @('shell','wm','density')
  'Memory info' = @('shell','cat','/proc/meminfo')
  'Free storage' = @('shell','df','-h','/data')
  'Package list (third-party flags and names)' = @('shell','pm','list','packages','-3','-f')
  'All package names' = @('shell','pm','list','packages')
  'HOME activities' = @('shell','cmd','package','query-activities','--brief','-a','android.intent.action.MAIN','-c','android.intent.category.HOME')
  'Resolved HOME' = @('shell','cmd','package','resolve-activity','--brief','-a','android.intent.action.MAIN','-c','android.intent.category.HOME')
  'Launcher packages and states' = @('shell','pm','list','packages','-e')
  'Star Screen Saver package query' = @('shell','pm','list','packages','star')
  'Projectivy package query' = @('shell','pm','list','packages','projectivy')
  'Display configuration' = @('shell','dumpsys','display')
  'Activity manager memory summary' = @('shell','dumpsys','meminfo')
}
foreach ($label in $commands.Keys) {
  $args = @('-s', "${TvHost}:$Port") + $commands[$label]
  $result = Run-Adb $args
  "`n=== $label ===`n$result" | Add-Content -Encoding UTF8 $log
}
# Query known Star component package IDs without disabling or enabling anything.
$pkgAll = Run-Adb @('-s', "${TvHost}:$Port", 'shell','pm','list','packages')
$star = $pkgAll -split "`r?`n" | Where-Object { $_ -match '(?i)star|screensaver|projectivy|sber|salute|launcher' }
"`n=== Packages matching star/screensaver/projectivy/sber/salute/launcher ===`n$($star -join "`n")" | Add-Content -Encoding UTF8 $log
Write-Host "Diagnostic completed. No packages/settings were modified. Report: $log"
Write-Host "Review for sensitive identifiers before sharing the report."
