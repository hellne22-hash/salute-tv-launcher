package ru.pavel.salutelauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Small, offline-first Android TV home screen. No services, permissions, or network access. */
public class MainActivity extends Activity {
    private static final String PREFS = "launcher_preferences";
    private static final String KEY_FAVS = "favorites";
    private static final String KEY_ORDER = "app_order";
    private static final String KEY_THEME = "theme";
    private static final int BG = Color.rgb(8, 9, 13);
    private static final int FG = Color.rgb(246, 247, 250);
    private static final int MUTED = Color.rgb(157, 162, 174);
    private static final int CARD = Color.rgb(25, 27, 35);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private LinearLayout root;
    private LinearLayout dock;
    private GridLayout appGrid;
    private TextView sectionTitle;
    private TextView hint;
    private boolean showAll = false;
    private boolean choosingFavorites = false;
    private List<AppEntry> apps = new ArrayList<>();
    private List<AppEntry> visibleApps = new ArrayList<>();
    private int themeIndex = 0;

    private static class AppEntry {
        String packageName, label;
        android.graphics.drawable.Drawable icon;
        AppEntry(String p, String l, android.graphics.drawable.Drawable i) { packageName=p; label=l; icon=i; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        themeIndex = prefs.getInt(KEY_THEME, 0);
        loadApps();
        buildHome();
    }

    @Override protected void onResume() { super.onResume(); if (prefs != null) { loadApps(); if (root != null) buildHome(); } }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private int accent() { return new int[]{Color.rgb(108, 145, 255), Color.rgb(104, 220, 183), Color.rgb(211, 143, 255)}[themeIndex % 3]; }

    private GradientDrawable bg(int color, int radius, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor); return d;
    }
    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL)); t.setGravity(Gravity.CENTER_VERTICAL); t.setIncludeFontPadding(false); return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void setMargin(View view, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom)); view.setLayoutParams(lp);
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN); query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> results = pm.queryIntentActivities(query, 0);
        // Package visibility is unrestricted for ordinary launcher activities on Android 11+ only when queried;
        // request HOME/LEANBACK activities too so typical TV apps are included.
        Intent lean = new Intent(Intent.ACTION_MAIN); lean.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        results.addAll(pm.queryIntentActivities(lean, 0));
        Set<String> seen = new HashSet<>(); apps.clear();
        String own = getPackageName();
        for (ResolveInfo ri : results) {
            if (ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(own) || !seen.add(pkg)) continue;
            try {
                ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                String label = pm.getApplicationLabel(ai).toString();
                android.graphics.drawable.Drawable icon = ri.loadIcon(pm);
                apps.add(new AppEntry(pkg, label, icon));
            } catch (Exception ignored) { /* app disappeared during enumeration */ }
        }
        final Collator collator = Collator.getInstance();
        Collections.sort(apps, (a,b) -> collator.compare(a.label, b.label));
        String orderRaw = prefs.getString(KEY_ORDER, "");
        if (!orderRaw.isEmpty()) {
            String[] ordered = orderRaw.split("\\n");
            List<AppEntry> orderedApps = new ArrayList<>();
            for (String p : ordered) for (AppEntry a : apps) if (a.packageName.equals(p)) { orderedApps.add(a); break; }
            for (AppEntry a : apps) if (!orderedApps.contains(a)) orderedApps.add(a);
            apps = orderedApps;
        }
    }

    private Set<String> favorites() {
        Set<String> f = new LinkedHashSet<>();
        String raw = prefs.getString(KEY_FAVS, "");
        for (String p : raw.split("\\n")) if (!p.trim().isEmpty()) f.add(p.trim());
        if (f.isEmpty()) {
            for (AppEntry a : apps) { if (f.size() >= 5) break; f.add(a.packageName); }
        }
        return f;
    }
    private void saveFavorites(Set<String> favorites) { prefs.edit().putString(KEY_FAVS, join(favorites)).apply(); }
    private String join(Iterable<String> values) { StringBuilder b = new StringBuilder(); for (String v : values) { if (b.length() > 0) b.append('\n'); b.append(v); } return b.toString(); }

    private void buildHome() {
        root = column(); root.setPadding(dp(42), dp(24), dp(42), dp(24)); root.setBackgroundColor(BG);
        setContentView(root);
        LinearLayout top = row(); top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout identity = column();
        TextView brand = text("SALUTE", 15, accent(), true); brand.setLetterSpacing(0.18f);
        TextView welcome = text("Ваш телевизор. Ваш выбор.", 25, FG, true);
        identity.addView(brand); setMargin(welcome, 0, 5, 0, 0); identity.addView(welcome);
        LinearLayout.LayoutParams identityLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1); top.addView(identity, identityLp);
        LinearLayout clockBox = column(); clockBox.setGravity(Gravity.RIGHT);
        TextClock clock = new TextClock(this); clock.setFormat24Hour("HH:mm"); clock.setFormat12Hour("h:mm a"); clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, 29); clock.setTextColor(FG); clock.setTypeface(Typeface.create("sans-serif-light", 0)); clock.setGravity(Gravity.RIGHT);
        TextClock date = new TextClock(this); date.setFormat24Hour("EEEE, d MMMM"); date.setFormat12Hour("EEEE, d MMMM"); date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13); date.setTextColor(MUTED); date.setGravity(Gravity.RIGHT);
        clockBox.addView(clock); setMargin(date, 0, 4, 0, 0); clockBox.addView(date); top.addView(clockBox);
        root.addView(top);

        TextView favLabel = text("ИЗБРАННОЕ", 13, MUTED, true); favLabel.setLetterSpacing(0.12f); setMargin(favLabel, 0, 28, 0, 12); root.addView(favLabel);
        HorizontalScrollView dockScroll = new HorizontalScrollView(this); dockScroll.setHorizontalScrollBarEnabled(false); dock = row(); dock.setGravity(Gravity.CENTER_VERTICAL); dockScroll.addView(dock); root.addView(dockScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(112)));
        populateDock();

        LinearLayout section = row(); section.setGravity(Gravity.CENTER_VERTICAL); setMargin(section, 0, 24, 0, 12);
        sectionTitle = text(showAll ? "Все приложения" : "Приложения", 19, FG, true); section.addView(sectionTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button allBtn = button(showAll ? "Главная" : "Все приложения", false); allBtn.setOnClickListener(v -> { showAll = !showAll; buildHome(); }); section.addView(allBtn);
        Button favBtn = button("Избранное", false); setMargin(favBtn, 8, 0, 0, 0); favBtn.setOnClickListener(v -> showFavoritesDialog()); section.addView(favBtn);
        Button settingsBtn = button("Настройки", true); setMargin(settingsBtn, 8, 0, 0, 0); settingsBtn.setOnClickListener(v -> showSettings()); section.addView(settingsBtn);
        root.addView(section);

        ScrollView appScroll = new ScrollView(this); appScroll.setVerticalScrollBarEnabled(false);
        appGrid = new GridLayout(this); appGrid.setColumnCount(getResources().getConfiguration().screenWidthDp >= 1500 ? 7 : getResources().getConfiguration().screenWidthDp >= 1000 ? 6 : 4);
        appGrid.setAlignmentMode(GridLayout.ALIGN_BOUNDS); appGrid.setUseDefaultMargins(false);
        appScroll.addView(appGrid); root.addView(appScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        populateGrid();
        hint = text("OK — открыть   •   Удерживайте OK на карточке — действия   •   Back — закрыть меню", 11, MUTED, false); setMargin(hint, 0, 10, 0, 0); root.addView(hint);
        root.setFocusableInTouchMode(true); root.requestFocus();
    }

    private Button button(String label, boolean selected) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12); b.setTextColor(selected ? BG : FG); b.setTypeface(Typeface.create("sans-serif-medium", 0));
        b.setPadding(dp(14), 0, dp(14), 0); b.setMinHeight(dp(42)); b.setMinimumHeight(dp(42)); b.setBackground(bg(selected ? FG : CARD, 18, Color.TRANSPARENT, 0));
        b.setFocusable(true); b.setOnFocusChangeListener((v, focused) -> { v.setBackground(bg(focused ? accent() : (selected ? FG : CARD), 18, focused ? Color.WHITE : Color.TRANSPARENT, focused ? 2 : 0)); ((Button)v).setTextColor(focused ? Color.BLACK : (selected ? BG : FG)); v.setScaleX(focused ? 1.04f : 1f); v.setScaleY(focused ? 1.04f : 1f); });
        return b;
    }

    private void populateDock() {
        dock.removeAllViews(); Set<String> favorites = favorites(); int count=0;
        for (AppEntry app : apps) if (favorites.contains(app.packageName)) {
            if (count++ >= 8) break;
            dock.addView(tile(app, true), new LinearLayout.LayoutParams(dp(150), dp(102)));
        }
        if (count == 0) { TextView empty=text("Нет приложений для запуска",14,MUTED,false); dock.addView(empty); }
    }

    private View tile(AppEntry app, boolean inDock) {
        LinearLayout tile = column(); tile.setGravity(Gravity.CENTER); tile.setFocusable(true); tile.setClickable(true); tile.setPadding(dp(8), dp(10), dp(8), dp(8)); tile.setBackground(bg(CARD, 18, Color.TRANSPARENT, 0));
        android.widget.ImageView icon = new android.widget.ImageView(this); icon.setImageDrawable(app.icon); icon.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        int iconSize = inDock ? 42 : 36; LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(iconSize), dp(iconSize)); tile.addView(icon, iconLp);
        TextView label = text(app.label, inDock ? 12 : 11, FG, true); label.setGravity(Gravity.CENTER); label.setMaxLines(2); label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)); labelLp.topMargin = dp(7); tile.addView(label, labelLp);
        tile.setOnFocusChangeListener((v, focus) -> { v.setBackground(bg(focus ? Color.rgb(48, 57, 78) : CARD, 18, focus ? accent() : Color.TRANSPARENT, focus ? 2 : 0)); v.setScaleX(focus ? 1.045f : 1f); v.setScaleY(focus ? 1.045f : 1f); });
        tile.setOnClickListener(v -> launch(app));
        tile.setOnLongClickListener(v -> { showAppActions(app); return true; });
        tile.setOnKeyListener((v, key, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN && (key == KeyEvent.KEYCODE_MENU || key == KeyEvent.KEYCODE_INFO)) { showAppActions(app); return true; }
            return false;
        });
        tile.setContentDescription(app.label);
        return tile;
    }

    private void populateGrid() {
        appGrid.removeAllViews(); visibleApps.clear(); Set<String> favorites = favorites();
        for (AppEntry a : apps) if (showAll || !favorites.contains(a.packageName)) visibleApps.add(a);
        int columns = appGrid.getColumnCount();
        for (AppEntry a : visibleApps) {
            View tile = tile(a, false); GridLayout.LayoutParams lp = new GridLayout.LayoutParams(); lp.width = 0; lp.height = dp(100); lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); lp.setMargins(dp(4), dp(4), dp(4), dp(4)); appGrid.addView(tile, lp);
        }
        if (visibleApps.isEmpty()) {
            TextView empty = text("Приложений не найдено. Нажмите «Избранное», чтобы выбрать карточки.", 14, MUTED, false);
            GridLayout.LayoutParams p = new GridLayout.LayoutParams(); p.width = ViewGroup.LayoutParams.MATCH_PARENT; appGrid.addView(empty,p);
        }
    }

    private void launch(AppEntry app) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(app.packageName);
            if (i == null) {
                i = new Intent(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER); i.setPackage(app.packageName);
                ResolveInfo r = getPackageManager().resolveActivity(i, 0);
                if (r != null) i.setComponent(new ComponentName(r.activityInfo.packageName, r.activityInfo.name));
            }
            if (i == null) { Toast.makeText(this, "У приложения нет доступного экрана запуска", Toast.LENGTH_SHORT).show(); return; }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
        } catch (ActivityNotFoundException | SecurityException ex) {
            Toast.makeText(this, "Не удалось открыть приложение: " + app.label, Toast.LENGTH_SHORT).show();
        }
    }

    private void showAppActions(AppEntry app) {
        String[] actions = { "Открыть", "Добавить/убрать из избранного", "Переместить выше", "Переместить ниже", "Информация о приложении" };
        new AlertDialog.Builder(this).setTitle(app.label).setItems(actions, (d, which) -> {
            if (which == 0) launch(app);
            else if (which == 1) { Set<String> f=favorites(); if (!f.add(app.packageName)) f.remove(app.packageName); saveFavorites(f); buildHome(); }
            else if (which == 2 || which == 3) { moveApp(app, which == 2 ? -1 : 1); loadApps(); buildHome(); }
            else if (which == 4) { Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS); i.setData(android.net.Uri.parse("package:" + app.packageName)); try { startActivity(i); } catch(Exception ignored) {} }
        }).show();
    }

    private void moveApp(AppEntry app, int direction) {
        int at = -1; for (int i=0;i<apps.size();i++) if (apps.get(i).packageName.equals(app.packageName)) { at=i; break; }
        int to=at+direction; if (at<0 || to<0 || to>=apps.size()) return;
        Collections.swap(apps, at, to); List<String> ids=new ArrayList<>(); for(AppEntry a:apps) ids.add(a.packageName); prefs.edit().putString(KEY_ORDER, join(ids)).apply();
    }

    private void showFavoritesDialog() {
        final String[] names = new String[apps.size()]; final boolean[] checked = new boolean[apps.size()]; Set<String> current = favorites();
        for (int i=0;i<apps.size();i++) { names[i]=apps.get(i).label; checked[i]=current.contains(apps.get(i).packageName); }
        new AlertDialog.Builder(this).setTitle("Избранные приложения (до 8 в верхнем ряду)").setMultiChoiceItems(names, checked, (d, which, isChecked) -> checked[which]=isChecked)
            .setPositiveButton("Сохранить", (d,w) -> { Set<String> fav=new LinkedHashSet<>(); for(int i=0;i<apps.size();i++) if(checked[i]) fav.add(apps.get(i).packageName); saveFavorites(fav); buildHome(); })
            .setNegativeButton("Отмена", null).show();
    }

    private void showSettings() {
        String[] choices = { "Сменить цветовую тему", "Выбрать системные обои", "Открыть настройки Android", "Обновить список приложений", "О приложении" };
        new AlertDialog.Builder(this).setTitle("Настройки лаунчера").setItems(choices, (d,w) -> {
            switch(w) {
                case 0: themeIndex=(themeIndex+1)%3; prefs.edit().putInt(KEY_THEME,themeIndex).apply(); buildHome(); break;
                case 1: try { startActivity(new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)); } catch(Exception e) { try { startActivity(new Intent(Intent.ACTION_SET_WALLPAPER)); } catch(Exception ignored) {} } break;
                case 2: try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch(Exception ignored) {} break;
                case 3: loadApps(); buildHome(); Toast.makeText(this,"Список обновлён",Toast.LENGTH_SHORT).show(); break;
                case 4: new AlertDialog.Builder(this).setTitle("Salute TV Launcher").setMessage("Локальный лаунчер без рекламы, аналитики, сетевого доступа и фоновых служб.\n\nПеречень приложений зависит от того, какие активности прошивка показывает PackageManager.").setPositiveButton("OK",null).show(); break;
            }
        }).show();
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (showAll) { showAll=false; buildHome(); return true; }
            return super.onKeyDown(keyCode,event);
        }
        if (keyCode == KeyEvent.KEYCODE_MENU) { showSettings(); return true; }
        return super.onKeyDown(keyCode,event);
    }
}
