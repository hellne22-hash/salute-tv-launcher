# Salute TV Launcher

A lightweight, offline-first Android TV launcher prototype tailored for Sber Salute TV. It uses PackageManager-discovered activities and app icons, has a favorites dock, app grid, on-TV favorites selection, app reordering via long-press actions, clock/date, theme accents and system settings shortcuts. No Internet permission, ads, analytics, services, or automatic package changes.

## Important compatibility note

The TV model and runtime Android SDK have not yet been verified: no ADB-connected TV was available during preparation. The provided firmware string (`TP1A.220905.004.A2.eng.tuz_st.20260617.000452`) alone is not sufficient to infer the exact hardware model or the behavior of Sber's HOME key interception. Installing a package does not prove it can become default HOME. Test using the chooser/settings if firmware exposes one; do not disable the stock HOME app.

The code registers `MAIN/HOME/DEFAULT`, `MAIN/LAUNCHER`, and `LEANBACK_LAUNCHER`. On Android 11+ package visibility and Sber-specific package-manager policy can still affect the app list. The manifest intentionally avoids broad `QUERY_ALL_PACKAGES`; it queries launcher categories.

## Build

Requirements: JDK 17, Android SDK Platform 35 and Gradle 8.7+ (AGP 8.6.1 is specified). From this directory:

```powershell
gradle assembleDebug
```

APK path: `app/build/outputs/apk/debug/app-debug.apk`.

A Gradle wrapper is not included yet. If Android Studio is installed, open the folder and sync/build there. Network restrictions in the current build environment prevented cloning the CleanYourTV repository and the Android SDK/Gradle are not installed, so an APK could not be built here.

## Windows read-only diagnostics

1. Install Android SDK Platform-Tools, so `adb.exe` is available in PATH.
2. In TV settings, enable developer options and ADB/network debugging if this model offers them. Note the TV's IP. Approve the computer authorization prompt shown on the TV. This procedure performs no package/settings changes.
3. Open PowerShell in this project directory and run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\tools\diagnose-salute-tv.ps1 -TvHost 192.168.1.50
```

Or run `tools\diagnose-salute-tv.bat 192.168.1.50 5555`. Replace the sample IP. The script records Android version/SDK, model, build fingerprint, resolution/density, RAM, data partition space, package list, HOME resolution and diagnostic dumps. Review the report for serial numbers, IPs and other private details before sending it anywhere.

## Install and test

After a build, connect with `adb connect TV_IP:5555`, then `adb install -r app/build/outputs/apk/debug/app-debug.apk`. Open the app from the app list first; do not disable the stock launcher. If HOME picker is available, choose **Salute TV Launcher**. If not, inspect `cmd package query-activities` and the OEM's HOME/remote-key behavior before drawing conclusions. Some vendor firmware intercepts the remote Home key or forces its own home activity, and an ordinary app cannot override that without OS/vendor privileges.

## Restore

Do not disable or remove Projectivy or the system HOME. If a HOME picker was used, open Android Settings → Apps → Default apps/Home app (wording varies) and select Projectivy or the stock home. If the picker is unavailable, long-press the launcher's app icon and open App info, then clear its defaults if shown. ADB fallback: `adb shell am start -a android.settings.SETTINGS`; actual settings activity availability varies by firmware. Only uninstall this package after the previous HOME has been selected and verified.

## Project status / verification

The source and read-only PowerShell diagnostic script were authored in this environment. No TV was connected, so no hardware properties, installed package states, HOME routing, or remote-key behavior are confirmed. The Android SDK, Gradle, and ADB executables were absent, and outbound DNS/network access prevented cloning CleanYourTV; therefore compilation, APK generation, emulator tests, and runtime tests have not been performed. Do not treat this source snapshot as a verified ready-to-install APK.

## Cloud build (when no Windows computer is available)

The repository includes `.github/workflows/build-apk.yml` for a GitHub Actions build on a hosted Linux runner. After the source folder is placed in a GitHub repository, open **Actions → Build Salute TV Launcher APK → Run workflow**. When the run finishes successfully, open the run and download the `salute-tv-launcher-debug-apk` artifact. Extract it on the phone and use the TV file manager to install the APK. GitHub account/repository setup is required; no APK is included in this source archive until a real build succeeds.
